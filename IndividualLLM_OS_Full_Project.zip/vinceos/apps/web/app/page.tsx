
export default function Home(){
  return <main style={{padding:40}}><h1>VinceOS</h1><p>Your personal AI brain.</p></main>
}
