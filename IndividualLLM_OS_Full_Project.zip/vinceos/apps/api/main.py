
from fastapi import FastAPI
from pydantic import BaseModel
app = FastAPI(title="VinceOS API")
class ChatRequest(BaseModel):
    message:str
@app.get("/health")
def health():
    return {"status":"ok"}
@app.post("/chat/query")
def chat(req: ChatRequest):
    return {"reply": f"You said: {req.message}"}
